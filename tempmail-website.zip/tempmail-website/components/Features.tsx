"use client"

import { motion } from 'framer-motion'
import { Mail, Phone, Shield, Zap } from 'lucide-react'

const features = [
  {
    icon: Mail,
    title: "Instant Disposable Email",
    description: "Receive emails instantly without registration."
  },
  {
    icon: Phone,
    title: "Temporary Phone Numbers",
    description: "SMS verification made easy with disposable numbers."
  },
  {
    icon: Shield,
    title: "Privacy First",
    description: "Your data is never stored."
  },
  {
    icon: Zap,
    title: "Fast and Free",
    description: "Get your temp services within seconds."
  }
]

export default function Features() {
  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex flex-col items-center text-center p-6 bg-background rounded-lg shadow-lg"
            >
              <feature.icon className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

