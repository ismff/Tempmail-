"use client"

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Mail, Phone } from 'lucide-react'

export default function Hero() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Protect Your Privacy with Temporary Emails & Numbers
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Generate disposable emails and phone numbers instantly for safe and hassle-free online verification.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="gap-2">
              <Mail className="w-5 h-5" />
              Generate Temp Email
            </Button>
            <Button size="lg" variant="outline" className="gap-2">
              <Phone className="w-5 h-5" />
              Generate Temp Number
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

