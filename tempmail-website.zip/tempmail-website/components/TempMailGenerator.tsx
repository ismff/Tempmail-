"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Copy, Loader2, RefreshCw, Trash2 } from 'lucide-react'
import { useToast } from "@/components/ui/use-toast"

interface Email {
  id: string
  from: string
  subject: string
  content: string
  date: string
}

export default function TempMailGenerator() {
  const [tempEmail, setTempEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [emails, setEmails] = useState<Email[]>([])
  const [showCopiedPopup, setShowCopiedPopup] = useState(false)
  const { toast } = useToast()

  const generateEmail = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/generate-email', {
        method: 'POST',
      })
      if (!response.ok) {
        throw new Error('Failed to generate email')
      }
      const data = await response.json()
      setTempEmail(data.email)
      toast({
        title: "Email Generated",
        description: "Your temporary email has been created successfully.",
      })
    } catch (error) {
      console.error('Error generating email:', error)
      toast({
        title: "Error",
        description: "Failed to generate email. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(tempEmail)
    setShowCopiedPopup(true)
    setTimeout(() => setShowCopiedPopup(false), 2000)
  }

  const refreshInbox = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/fetch-emails?email=${encodeURIComponent(tempEmail)}`)
      if (!response.ok) {
        throw new Error('Failed to fetch emails')
      }
      const data = await response.json()
      setEmails(data.emails)
    } catch (error) {
      console.error('Error fetching emails:', error)
      toast({
        title: "Error",
        description: "Failed to refresh inbox. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const deleteEmail = async (id: string) => {
    try {
      const response = await fetch(`/api/delete-email`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id, email: tempEmail }),
      })
      if (!response.ok) {
        throw new Error('Failed to delete email')
      }
      setEmails(emails.filter(email => email.id !== id))
      toast({
        title: "Deleted",
        description: "Email has been deleted.",
      })
    } catch (error) {
      console.error('Error deleting email:', error)
      toast({
        title: "Error",
        description: "Failed to delete email. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative"
    >
      <Card>
        <CardHeader>
          <CardTitle>Temporary Email Generator</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Input
                value={tempEmail}
                readOnly
                placeholder="Your temporary email will appear here"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={copyToClipboard}
                disabled={!tempEmail}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex space-x-2">
              <Button onClick={generateEmail} disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Generate Email
              </Button>
              <Button
                variant="outline"
                onClick={refreshInbox}
                disabled={loading || !tempEmail}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh Inbox
              </Button>
            </div>

            {tempEmail && (
              <Alert>
                <AlertDescription>
                  This email address will expire in 10 minutes. Generate a new one if needed.
                </AlertDescription>
              </Alert>
            )}

            <Tabs defaultValue="inbox" className="mt-6">
              <TabsList>
                <TabsTrigger value="inbox">Inbox</TabsTrigger>
                <TabsTrigger value="info">Information</TabsTrigger>
              </TabsList>
              <TabsContent value="inbox">
                {emails.length > 0 ? (
                  <div className="space-y-4">
                    {emails.map((email) => (
                      <Card key={email.id}>
                        <CardContent className="pt-6">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-semibold">{email.subject}</h3>
                              <p className="text-sm text-muted-foreground">
                                From: {email.from}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {email.date}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteEmail(email.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="text-sm">{email.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-4">
                    No emails received yet
                  </p>
                )}
              </TabsContent>
              <TabsContent value="info">
                <div className="space-y-4">
                  <p>Your temporary email address can be used for:</p>
                  <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                    <li>Signing up for services</li>
                    <li>Receiving verification codes</li>
                    <li>Testing email functionality</li>
                    <li>Avoiding spam in your personal inbox</li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>
      <AnimatePresence>
        {showCopiedPopup && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground px-4 py-2 rounded-md shadow-lg"
          >
            Email copied successfully!
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

