"use client"

import { createContext, useContext, useState } from 'react'
import { Chatbot } from './Chatbot'

const ChatbotContext = createContext({
  isOpen: false,
  toggleChat: () => {},
})

export function ChatbotProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false)

  const toggleChat = () => setIsOpen(!isOpen)

  return (
    <ChatbotContext.Provider value={{ isOpen, toggleChat }}>
      {children}
      <Chatbot />
    </ChatbotContext.Provider>
  )
}

export const useChatbot = () => useContext(ChatbotContext)

