"use client"

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

export default function APIKeysPage() {
  const [apiKey, setApiKey] = useState('')

  const generateApiKey = () => {
    // In a real application, this would be a server-side operation
    const newApiKey = 'tk_' + Math.random().toString(36).substr(2, 9)
    setApiKey(newApiKey)
    toast({
      title: "API Key Generated",
      description: "Your new API key has been created successfully.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8">API Keys</h1>
      <Card>
        <CardHeader>
          <CardTitle>Generate API Key</CardTitle>
          <CardDescription>Create a new API key to access TempMailX API</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Input value={apiKey} readOnly placeholder="Your API key will appear here" />
            <Button onClick={generateApiKey}>Generate New API Key</Button>
          </div>
        </CardContent>
        <CardFooter>
          <p className="text-sm text-muted-foreground">Keep your API key secret. Do not share it publicly.</p>
        </CardFooter>
      </Card>
    </div>
  )
}

