import { NextResponse } from 'next/server'

export async function POST() {
  const randomString = Math.random().toString(36).substring(7)
  const email = `${randomString}@tempmailpro.com`

  return NextResponse.json({ email })
}

