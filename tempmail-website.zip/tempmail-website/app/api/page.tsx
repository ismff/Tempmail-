import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function APIPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8">API Documentation</h1>
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="authentication">Authentication</TabsTrigger>
          <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>API Overview</CardTitle>
              <CardDescription>Learn about our API and how to integrate it into your applications.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>The TempMailX API allows you to programmatically create and manage temporary email addresses. With our API, you can:</p>
              <ul className="list-disc list-inside mt-4 space-y-2">
                <li>Generate temporary email addresses</li>
                <li>Retrieve messages for a given email address</li>
                <li>Delete messages</li>
                <li>Check email address validity</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="authentication">
          <Card>
            <CardHeader>
              <CardTitle>Authentication</CardTitle>
              <CardDescription>Learn how to authenticate your API requests.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>To use the TempMailX API, you need to include your API key in the header of each request:</p>
              <pre className="bg-muted p-4 rounded-md mt-4">
                <code>
                  {`Authorization: Bearer YOUR_API_KEY`}
                </code>
              </pre>
              <p className="mt-4">You can obtain an API key from your account dashboard.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="endpoints">
          <Card>
            <CardHeader>
              <CardTitle>API Endpoints</CardTitle>
              <CardDescription>Explore the available API endpoints and their usage.</CardDescription>
            </CardHeader>
            <CardContent>
              <h3 className="text-lg font-semibold mb-2">Generate Email</h3>
              <pre className="bg-muted p-4 rounded-md">
                <code>
                  {`POST /api/v1/email/generate
                  
Response:
{
  "email": "random123@tempmailx.com",
  "expires_at": "2023-05-20T15:30:00Z"
}`}
                </code>
              </pre>
              
              <h3 className="text-lg font-semibold mt-6 mb-2">Get Messages</h3>
              <pre className="bg-muted p-4 rounded-md">
                <code>
                  {`GET /api/v1/email/{email_address}/messages
                  
Response:
{
  "messages": [
    {
      "id": "msg123",
      "from": "sender@example.com",
      "subject": "Test Email",
      "body": "This is a test email.",
      "received_at": "2023-05-19T10:15:30Z"
    }
  ]
}`}
                </code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

