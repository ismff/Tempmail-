import { NextResponse } from 'next/server'

export async function GET() {
  // Simulate API response
  // In a real-world scenario, you might want to check actual service status here
  return NextResponse.json({ status: 'ok', message: 'TempMail service is operational' })
}

