"use client"

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, XCircle } from 'lucide-react'

export default function TroubleshootingPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleTestConnection = async () => {
    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      const response = await fetch('/api/test')
      if (!response.ok) {
        throw new Error('Network response was not ok')
      }
      setSuccess(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-4 space-y-4">
      <h1 className="text-3xl font-bold mb-6">TempMail Troubleshooting</h1>
      <Card>
        <CardHeader>
          <CardTitle>Service Status and Troubleshooting</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Common Issues Checklist</h2>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <span>Email generation working</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <span>Inbox refreshing properly</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <span>AI-assisted replies functional</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <span>Premium features accessible</span>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Test TempMail Service</h2>
            <Button 
              onClick={handleTestConnection}
              disabled={isLoading}
            >
              {isLoading ? 'Testing...' : 'Test Connection'}
            </Button>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <AlertTitle className="text-green-800">Success</AlertTitle>
                <AlertDescription className="text-green-700">
                  TempMail service is working correctly
                </AlertDescription>
              </Alert>
            )}
          </div>

          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Troubleshooting Steps</h2>
            <ol className="space-y-2 list-decimal list-inside">
              <li>Clear browser cache and cookies</li>
              <li>Check your internet connection</li>
              <li>Verify your account status (for premium features)</li>
              <li>Ensure you're using a supported browser</li>
              <li>Check for any ongoing service disruptions</li>
              <li>Contact support if issues persist</li>
            </ol>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Debug Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Client Version: 1.0.0
            </p>
            <p className="text-sm text-muted-foreground">
              Last Sync: {new Date().toLocaleString()}
            </p>
            <p className="text-sm text-muted-foreground">
              User Agent: {navigator.userAgent}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

