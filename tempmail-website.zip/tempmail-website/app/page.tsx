import Hero from '@/components/Hero'
import Features from '@/components/Features'
import TempMailGenerator from '@/components/TempMailGenerator'

export default function Home() {
  return (
    <div>
      <Hero />
      <Features />
      <div className="container mx-auto px-4 py-20">
        <TempMailGenerator />
      </div>
    </div>
  )
}

