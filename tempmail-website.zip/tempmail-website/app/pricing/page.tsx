import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

const plans = [
  {
    name: "Basic",
    price: "Free",
    features: [
      "Temporary email addresses",
      "10MB storage",
      "24-hour email expiration",
      "Basic support",
    ],
    cta: "Get Started",
    href: "/register",
  },
  {
    name: "Premium",
    price: "$9.99/month",
    features: [
      "Connect own custom domain",
      "100% Private email addresses",
      "Multiple mailboxes/addresses",
      "Access to premium domains",
      "100MB storage",
      "Cross-platform functionality",
      "Mobile apps for Android and iOS",
      "Full synchronization",
      "No ads",
      "Premium support",
      "Send, reply, and forward to real email (Coming soon)",
      "Automatic rules and webhooks (Coming soon)",
      "Collaborative inboxes (Coming soon)",
    ],
    cta: "Upgrade Now",
    href: "/upgrade",
  },
]

export default function PricingPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-center mb-12">Choose Your Plan</h1>
      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {plans.map((plan) => (
          <Card key={plan.name} className="flex flex-col">
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>
                <span className="text-3xl font-bold">{plan.price}</span>
                {plan.price !== "Free" && <span className="text-sm ml-1">/month</span>}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="list-disc list-inside space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href={plan.href}>{plan.cta}</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

