"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { MenuIcon, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { useMediaQuery } from '@/hooks/use-media-query'

const menuItems = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About Us' },
  { href: '/premium', label: 'Premium Package' },
  { href: '/contact', label: 'Contact' },
  { href: '/terms', label: 'Terms of Service' },
]

export function Menu() {
  const [isOpen, setIsOpen] = useState(false)
  const isDesktop = useMediaQuery("(min-width: 768px)")

  useEffect(() => {
    if (isDesktop && isOpen) {
      setIsOpen(false)
    }
  }, [isDesktop])

  const toggleMenu = () => setIsOpen(!isOpen)

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleMenu}
        aria-label="Toggle menu"
        className="md:hidden"
      >
        {isOpen ? <X className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
      </Button>
      <AnimatePresence>
        {(isOpen || isDesktop) && (
          <motion.nav
            initial={isDesktop ? false : { opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className={`${isDesktop ? 'static flex' : 'absolute right-0 mt-2'} w-56 md:w-auto bg-background border border-border md:border-none rounded-md shadow-lg md:shadow-none`}
          >
            <ul className={`py-1 md:py-0 ${isDesktop ? 'flex space-x-4' : ''}`}>
              {menuItems.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="block px-4 py-2 text-sm text-foreground hover:bg-muted md:hover:bg-transparent md:hover:text-primary transition-colors"
                    onClick={() => !isDesktop && setIsOpen(false)}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </div>
  )
}

