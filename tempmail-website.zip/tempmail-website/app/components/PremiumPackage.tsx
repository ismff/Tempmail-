import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from 'lucide-react'

const features = [
  "Connect your own custom domain",
  "100% Private email addresses with full control and ownership",
  "Multiple mailboxes/addresses with simultaneous usage",
  "Access to a special list of premium domains",
  "Extended 100MB storage for email messages",
  "Seamless cross-platform functionality",
  "Mobile apps with Premium for Android or iOS",
  "Full synchronization between Desktop/Web and Mobile",
  "No ads on desktop and mobile",
  "Premium support service",
  "Send, reply, and forward to real email (Coming soon)",
  "Automatic rules and webhooks combined with a new robust API (Coming soon)",
  "Collaborative inboxes for teams and organizations (Coming soon)"
]

export default function PremiumPackage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl">Premium Package</CardTitle>
          <CardDescription>Unlock advanced features and enhanced privacy</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {features.map((feature, index) => (
              <motion.li
                key={index}
                className="flex items-start"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <span>{feature}</span>
              </motion.li>
            ))}
          </ul>
        </CardContent>
        <CardFooter>
          <Button className="w-full">Upgrade to Premium - $9.99/month</Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}

