'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Copy, RefreshCw, Send, Trash2 } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useCompletion } from 'ai/react'
import { motion } from 'framer-motion'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const prefixes = ['user', 'temp', 'anon', 'private', 'secure']
const domains = ['tempmailpro.com', 'securetemp.org', 'anonmail.io']

export default function TempMailGenerator() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [messages, setMessages] = useState([])
  const [replyTo, setReplyTo] = useState('')
  const [replySubject, setReplySubject] = useState('')
  const [selectedPrefix, setSelectedPrefix] = useState(prefixes[0])
  const [selectedDomain, setSelectedDomain] = useState(domains[0])

  const { complete, completion, isLoading } = useCompletion({
    api: '/api/generate',
  })

  const generateEmail = () => {
    setLoading(true)
    const randomNum = Math.floor(Math.random() * 10000)
    const newEmail = `${selectedPrefix}${randomNum}@${selectedDomain}`
    setEmail(newEmail)
    setLoading(false)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(email)
  }

  const refreshInbox = () => {
    setLoading(true)
    // Simulate API call to fetch messages
    setTimeout(() => {
      setMessages([
        { id: 1, from: 'sender@example.com', subject: 'Welcome to TempMail Pro', body: 'Thank you for using our service!', date: new Date().toLocaleString() },
        { id: 2, from: 'noreply@service.com', subject: 'Confirm your account', body: 'Please click the link to confirm your account.', date: new Date().toLocaleString() },
      ])
      setLoading(false)
    }, 1000)
  }

  const handleReply = (message) => {
    setReplyTo(message.from)
    setReplySubject(`Re: ${message.subject}`)
  }

  const handleAIAssist = async (prompt) => {
    await complete(prompt)
  }

  const handleSendEmail = () => {
    // Implement email sending functionality here
    console.log('Sending email...')
  }

  const handleDeleteEmail = (id) => {
    setMessages(messages.filter(message => message.id !== id))
  }

  useEffect(() => {
    generateEmail()
  }, [])

  return (
    <Card className="w-full max-w-4xl mx-auto mb-8">
      <CardHeader>
        <CardTitle>Temporary Email Generator</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <Select value={selectedPrefix} onValueChange={setSelectedPrefix}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select prefix" />
            </SelectTrigger>
            <SelectContent>
              {prefixes.map(prefix => (
                <SelectItem key={prefix} value={prefix}>{prefix}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            type="text"
            placeholder="Your temporary email"
            value={email}
            readOnly
            className="flex-grow"
          />
          <Select value={selectedDomain} onValueChange={setSelectedDomain}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select domain" />
            </SelectTrigger>
            <SelectContent>
              {domains.map(domain => (
                <SelectItem key={domain} value={domain}>{domain}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={copyToClipboard} disabled={!email}>
            <Copy className="w-4 h-4 mr-2" />
            Copy
          </Button>
        </div>
        <div className="flex justify-between mb-6">
          <Button onClick={generateEmail} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
            Generate Email
          </Button>
          <Button onClick={refreshInbox} disabled={loading || !email}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh Inbox
          </Button>
        </div>
        <Tabs defaultValue="inbox">
          <TabsList>
            <TabsTrigger value="inbox">Inbox</TabsTrigger>
            <TabsTrigger value="compose">Compose</TabsTrigger>
          </TabsList>
          <TabsContent value="inbox">
            {messages.length > 0 ? (
              <ul className="space-y-4">
                {messages.map((message) => (
                  <motion.li
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="border-b pb-2"
                  >
                    <p className="font-semibold">{message.subject}</p>
                    <p className="text-sm text-muted-foreground">From: {message.from}</p>
                    <p className="text-sm text-muted-foreground">{message.date}</p>
                    <p className="mt-2">{message.body}</p>
                    <div className="mt-2 space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleReply(message)}>
                        Reply
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteEmail(message.id)}>
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </motion.li>
                ))}
              </ul>
            ) : (
              <p>No messages yet. Generate an email and refresh your inbox.</p>
            )}
          </TabsContent>
          <TabsContent value="compose">
            <div className="space-y-4">
              <Input
                type="text"
                placeholder="To"
                value={replyTo}
                onChange={(e) => setReplyTo(e.target.value)}
              />
              <Input
                type="text"
                placeholder="Subject"
                value={replySubject}
                onChange={(e) => setReplySubject(e.target.value)}
              />
              <Textarea
                placeholder="Write your message here"
                value={completion}
                onChange={(e) => complete(e.target.value)}
                rows={6}
              />
              <div className="flex justify-between">
                <Button onClick={() => handleAIAssist("Write a professional email reply")} disabled={isLoading}>
                  AI Assist
                </Button>
                <Button onClick={handleSendEmail}>
                  <Send className="w-4 h-4 mr-2" />
                  Send
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

