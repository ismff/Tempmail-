"use client"

import Link from 'next/link'
import { ModeToggle } from './ModeToggle'
import { Menu } from './Menu'
import { motion } from 'framer-motion'

export default function Header() {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-background border-b"
    >
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-primary">
            <motion.span
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              TempMail Pro
            </motion.span>
          </Link>
          <div className="flex items-center space-x-4">
            <ModeToggle />
            <Menu />
          </div>
        </div>
      </nav>
    </motion.header>
  )
}

