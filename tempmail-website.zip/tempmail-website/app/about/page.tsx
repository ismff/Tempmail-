import { motion } from 'framer-motion'

export default function AboutPage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-8"
    >
      <h1 className="text-3xl font-bold mb-4">About TempMail Pro</h1>
      <p className="mb-4">
        TempMail Pro is a cutting-edge temporary email service designed to protect your privacy and streamline your online communications. Our mission is to provide secure, disposable email addresses with advanced features that cater to both personal and professional needs.
      </p>
      <p className="mb-4">
        Founded in 2023, our team of privacy enthusiasts and tech experts have worked tirelessly to create a platform that combines ease of use with robust security measures. We understand the importance of protecting your personal information in today's digital landscape, and we're committed to offering a service that puts your privacy first.
      </p>
      <p>
        With TempMail Pro, you can enjoy features like AI-assisted replies, custom domains, and extended email storage, all while maintaining your anonymity online. Whether you're signing up for a new service, managing multiple accounts, or simply looking to reduce spam in your primary inbox, TempMail Pro has you covered.
      </p>
    </motion.div>
  )
}

