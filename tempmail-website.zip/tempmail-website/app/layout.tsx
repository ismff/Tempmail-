import './globals.css'
import { Inter } from 'next/font/google'
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { ChatbotProvider } from '@/components/ChatbotProvider'
import { Metadata } from 'next'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'TempMailX - Secure Temporary Email Service',
  description: 'Generate disposable emails instantly for safe and hassle-free online verification.',
  keywords: ['temporary email', 'disposable email', 'email privacy', 'online security'],
  authors: [{ name: 'TempMailX Team' }],
  creator: 'TempMailX',
  publisher: 'TempMailX',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <ChatbotProvider>
            <div className="flex min-h-screen flex-col">
              <Header />
              <main className="flex-1">
                {children}
              </main>
              <Footer />
            </div>
            <Toaster />
          </ChatbotProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

