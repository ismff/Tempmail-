import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

const blogPosts = [
  {
    slug: "how-to-choose-disposable-email",
    title: "How to Choose a Disposable Email?",
    description: "Learn the factors to consider when selecting a disposable email service.",
  },
  {
    slug: "why-need-fake-email-address",
    title: "Why would you need a fake email address?",
    description: "Discover the various reasons and benefits of using a temporary email address.",
  },
  {
    slug: "what-is-disposable-email-address",
    title: "So, What Is A Disposable Email Address?",
    description: "Understand the concept and functionality of disposable email addresses.",
  },
  {
    slug: "tech-behind-disposable-email-addresses",
    title: "The Tech behind Disposable Email Addresses",
    description: "Explore the technology and infrastructure that powers temporary email services.",
  },
]

export default function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Blog</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {blogPosts.map((post) => (
          <Card key={post.slug}>
            <CardHeader>
              <CardTitle>{post.title}</CardTitle>
              <CardDescription>{post.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={`/blog/${post.slug}`} className="text-primary hover:underline">
                Read more
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

