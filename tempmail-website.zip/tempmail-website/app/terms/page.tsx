import { motion } from 'framer-motion'

export default function TermsPage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-8"
    >
      <h1 className="text-3xl font-bold mb-4">Terms of Service</h1>
      <p className="mb-4">
        Welcome to TempMail Pro. By using our service, you agree to comply with and be bound by the following terms and conditions of use. Please review these terms carefully.
      </p>
      <h2 className="text-2xl font-bold mt-6 mb-2">1. Acceptance of Terms</h2>
      <p className="mb-4">
        By accessing or using TempMail Pro, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any part of these terms, you may not use our service.
      </p>
      <h2 className="text-2xl font-bold mt-6 mb-2">2. Use of Service</h2>
      <p className="mb-4">
        TempMail Pro provides temporary email addresses for personal and professional use. You agree to use this service only for lawful purposes and in a way that does not infringe the rights of, restrict or inhibit anyone else's use and enjoyment of the service.
      </p>
      <h2 className="text-2xl font-bold mt-6 mb-2">3. Privacy Policy</h2>
      <p className="mb-4">
        Your use of TempMail Pro is also governed by our Privacy Policy. Please review our Privacy Policy, which also governs the site and informs users of our data collection practices.
      </p>
      <h2 className="text-2xl font-bold mt-6 mb-2">4. Modifications</h2>
      <p className="mb-4">
        TempMail Pro reserves the right, at its sole discretion, to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect.
      </p>
    </motion.div>
  )
}

